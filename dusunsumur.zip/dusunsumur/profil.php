<!DOCTYPE html>
<html>
<head>
    <title>Profil Rumah Sakit</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
 <style>
        body {
	background-image: url(suci.png);
	background-size: cover;
	background-repeat: no-repeat;
	background-attachment: fixed;
        }
        </style>
<body>
    <h2><underline>
      <div align="center">Profil Dusun Sumur </div>
    </underline></h2>
    <table width="1017" border="0" align="center">
      <tr>
        <td width="405"><img src="kali.jpg" width="403" height="249"></td>
        <td width="602"><p><strong>Sejarah Dusun Sumur</strong></p>
          <p>Dusun Ngemplak merupakan nama awal  dari Dusun Sumur. Nama Dusun Sumur berubah karena adanya perkembangan. Dusun  Sumur ini diperjuangkan oleh Sunan Ampel Gading karena sering bertapa di Kali  Sumur. Berikut nama Kepala Dusun Sumur beserta masa jabatannya.</p>
          <p align="justify">Kepala  Dusun 13 Irontono 1940-1960<br>
            Kepala  Dusun Pak Tokarno 1960-1963<br>
            Kepala  Dusun Pak Kartoyo 1963-1995 <br>
            Kepala  Dusun Pak Sarmadi 1995-2002<br>
            Kepala  Dusun Pak Topik 1995-2003 <br>
          Kepala  Dusun Pak Tamin 2003-Sekarang</p>          </td>
      </tr>
      <tr>
        <td><img src="maps1.jpg" width="401" height="255"></td>
        <td><p align="justify"><strong>Letak Geografi Dusun Sumur </strong></p>
          <p align="justify">Dusun Sumur terletak di Desa Suci, Kecamatan  Pracimantoro, Kabupaten Wonogiri. Jarak Dusun Sumur menuju ke Kecamatan  Pracimantoro sekitar 8,1 KM dan jarak ke Kabupaten Wonogiri sekitar 53 KM.  Batas wilayah timur Dusun Sumur yaitu Kecamatan Giritontro, batas selatan Desa  Gambirmanis, batas barat Dusun Pondok, dan batas utara Dusun Sinung. Dusun  Sumur terdiri dari 2 RW dan 4 RT</p>
          <p><strong>Batas Wilayah Dusun Sumur</strong></p>
          <ul>
          <li>Timur&nbsp; : Kecamatan Giritontro</li>
          <li>Selatan : Desa Gambirmanis</li>
          <li>Barat&nbsp;&nbsp; : Dusun Pondok</li>
          <li>Utara  &nbsp; : Dusun Sinung</li>
          </ul>
        </p></td>
      </tr>
      <tr>
        <td><img src="penduduk.jpg" width="404" height="520"></td>
        <td><p><strong>Kependudukan Dusun Sumur</strong></p>
        <p align="justify">Jumlah penduduk Dusun Sumur pada tahun 2024 tercatat  sebanyak 504 orang yang terdiri dari 250 penduduk laki-laki, 254 penduduk  Perempuan, 25 balita, 35 anakanak, 97 remaja, 142 dewasa, dan 205 lansia.</p>
        <p align="justify">Untuk jumlah keluarga tercatat sebanyak 188 kepala  keluarga dengan rincian 36 kartu keluarga terdapat di RT 01, 58 kartu keluarga  terdapat di RT 02, 45 kartu keluarga terdapat di RT 03, dan 49 kartu keluarga  terdapat di RT 04.</p>
        <p align="justify"><strong>Mata Pencarian</strong> <strong>Dusun Sumur</strong></p>
        <p>Mata pencaharian  pokok Masyarakat Dusun Sumur adalah sebagai Petani atau Pekebun dengan jumlah  167 orang. Mata pencaharian lain yaitu sebagai Karyawan Swasta dengan jumlah 88  orang dan Wiraswasta sebanyak 62 orang. </p>        
        <p align="justify"><strong>Pendidikan</strong> <strong>Dusun Sumur</strong></p>
        <p>Pendidikan yang  tinggi akan dapat meningkatkan kualitas SDM. Rata-rata Pendidikan Masyarakat  Dusun Sumur adalah Tamat SD/Sederajat dengan jumlah 219 orang, Belum Tamat  SD/Sederajat sebanyak 72 orang, SLTP/Sederajat sebanyak 115 orang,  SLTA/Sederajat 27 orang, Diploma IV/Strata I sebanyak 3 orang, dan Tidak/Belum  Sekolah sebanyak 68 orang.</p>
        <p align="justify"><strong>Kepercayaan</strong> <strong>Dusun Sumur</strong></p>
        <p>Penduduk Dusun  Sumur semua beragama islam dengan jumlah total sebanyak 504 orang. Sarana  peribadatan yang diinventariskan meliputi masjid sebanyak 1 buah.</p>        </td>
      </tr>
    </table>
    <p align="left">&nbsp;</p>
</body>
</html>

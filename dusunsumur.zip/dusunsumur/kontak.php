 <style>
        body {
	background-image: url(suci.png);
	background-size: cover;
	background-repeat: no-repeat;
	background-attachment: fixed;
        }
        </style>
<h2 align="center">Kontak Person Dusun Sumur </h2>
<table width="303" border="0" align="center">
  <tr>
    <td width="40"><img src="wa.png" width="40" height="40" /></td>
    <td width="253">+62 882-0060-13279</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="left">Pak Tamin ( Kepala Dusun Sumur) </div></td>
  </tr>
</table>

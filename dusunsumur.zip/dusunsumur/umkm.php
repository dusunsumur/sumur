<!DOCTYPE html>
<html>
<head>
    <title>Dokter Rumah Sakit</title>
	 <style>
        body {
	background-image: url(suci.png);
	background-size: cover;
	background-repeat: no-repeat;
	background-attachment: fixed;
        }
        </style>
</head>
<body>
    <h2 align="center">UMKM Dusun Sumur </h2>
    <p align="center">Beberapa UMKMi  yang dapat ditemukan di Dusun Sumur  </p>
    <table width="647" border="0" align="center">
      <tr>
        <td width="305"><img src="umkm1.jpg" width="305" height="342"></td>
        <td width="25">&nbsp;</td>
        <td width="303"><img src="umkm2.jpg" width="302" height="338"></td>
      </tr>
      <tr>
        <td height="59"><p align="center"><strong>Olahan Makanan</strong></p>
        <p align="center"><strong>Rengginan Tiwul </strong></p></td>
        <td><p align="center">&nbsp;</p>        </td>
        <td><p align="center"><strong>Olahan Makanan</strong></p>
        <p align="center"><strong>Keripik Tempe Tanpa Ragi </strong></p></td>
      </tr>
      <tr>
        <td height="322"><div align="justify">
          <p>Rengginang tiwul adalah salah satu kuliner tradisional  yang menjadi ciri khas Dusun Sumur. Makanan ini terbuat dari tiwul singkong,  yaitu singkong yang telah melalui proses pengolahan menjadi tiwul, kemudian  dibentuk dan dikeringkan. Setelah proses pengeringan selesai, tiwul tersebut  digoreng hingga menghasilkan tekstur yang renyah dan cita rasa yang unik.  Proses pembuatan rengginang tiwul ini memiliki kesamaan dengan pembuatan  rengginang pada umumnya, namun perbedaannya terletak pada bahan dasarnya. Rengginan  tiwul ini memiliki rasa yang beragam, mulai dari manis hingga pedas, sehingga  menjadi pilihan yang menarik sebagai oleh-oleh khas dari Dusun Sumur. Produk  ini telah dikenal luas dan sering dipesan oleh masyarakat dari berbagai daerah  sebagai buah tangan ketika mengunjungi Dusun Sumur, Desa Suci. Keunikan dan  cita rasa yang khas menjadikan rengginang tiwul sebagai salah satu ikon kuliner  dari daerah tersebut. </p>
        </div></td>
        <td>&nbsp;</td>
        <td valign="top"><div align="justify">Di Dusun Sumur, terdapat banyak warga yang memproduksi  makanan tempe. Namun, berbeda dengan olahan tempe pada umumnya, olahan tempe di  Dusun Sumur tidak menggunakan ragi dalam proses pembuatannya. Oleh karena itu,  tempe yang dihasilkan dianggap lebih alami. Tempe  yang diproduksi kemudian diolah menjadi keripik tempe, yang dijual di toko-toko  sekitar Desa Suci. Penjualan keripik tempe ini menjadi sumber pendapatan  tambahan bagi warga Dusun Sumur, membantu meningkatkan kesejahteraan ekonomi  masyarakat setempat. Proses produksi yang unik dan hasil produk yang alami  menjadikan keripik tempe dari Dusun Sumur memiliki nilai tambah tersendiri.<strong> </strong></div></td>
      </tr>
    </table>
    <p align="center">&nbsp;</p>
</body>
</html>

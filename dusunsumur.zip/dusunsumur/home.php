<!DOCTYPE html>
<html>
<head>
    <title>Home Rumah Sakit</title>
	    <style>
        body {
	background-image: url(suci.png);
	background-size: cover;
	background-repeat: no-repeat;
	background-attachment: fixed;
        }
        </style>
</head>
<body>
    <h2 align="center"><underline>
      <div align="center">Selamat Datang di Dusun Sumur </div>
    </underline></h2>
    <div align="center">
      <table width="800" border="0">
        <tr>
          <td width="209"><img src="home.jpg" width="307" height="225"></td>
          <td width="581"><p align="justify">Kami dengan senang hati menyambut Anda di website resmi Dusun Sumur. Di sini, Anda akan menemukan berbagai informasi penting dan menarik seputar perkembangan di dusun kami. Kami berharap website ini dapat menjadi jembatan komunikasi antara warga Dusun Sumur dan masyarakat luas, serta sarana untuk mempererat tali silaturahmi.</p>
            <p>Terima kasih telah mengunjungi website kami. Selamat menjelajahi dan semoga Anda mendapatkan informasi yang bermanfaat!</p>
            <p>Hormat kami,</p>
          <p><strong>Tim Pengelola Website Dusun Sumur</strong></p></td>
        </tr>
          </table>
    </div>
<p align="center">&nbsp;</p>
</body>
</html>


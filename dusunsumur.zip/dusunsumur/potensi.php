<!DOCTYPE html>
<html>
<head>
    <title>Dokter Rumah Sakit</title>
	 <style>
        body {
	background-image: url(suci.png);
	background-size: cover;
	background-repeat: no-repeat;
	background-attachment: fixed;
        }
        </style>
</head>
<body>
    <h2 align="center">Potensi Dusun Sumur </h2>
    <p align="center">Beberapa Potensi  yang dapat ditemukan di Dusun Sumur  </p>
    <table width="751" border="0" align="center">
      <tr>
        <td width="231" align="left"><img src="potensi1.jpg" width="231" height="255"></td>
        <td width="20">&nbsp;</td>
        <td width="232"><img src="potensi2.jpg" width="229" height="255"></td>
        <td width="18">&nbsp;</td>
        <td width="228"><img src="ternak.jpg" width="225" height="250"></td>
      </tr>
      <tr>
        <td align="left"><p align="center"><strong>Tempat Wisata</strong></p>
        <p align="center"><strong>Gunung Dewa Dewi </strong></p></td>
        <td><div align="center"></div></td>
        <td><div align="center"><strong>Petani</strong> &amp;<strong>Berkebun</strong></div></td>
        <td>&nbsp;</td>
        <td><div align="center"><strong>Peternak</strong></div></td>
      </tr>
      <tr>
        <td align="left"><div align="justify">Gunung Dewa Dewi merupakan sebuah gunung yang dijadikan kebun buah  alpukat. Di puncaknya, dibangun sebuah taman. Taman ini memanjang dari timur ke  barat dan dilengkapi dengan ornamen-ornamen patung dewa dan dewi, gazebo, serta  kolam ikan. Saat ini, Gunung Dewa Dewi masih dalam proses pembangunan. Ke  depannya, akan ditambah fasilitas seperti tempat makan dan area berkemah. Jam  operasional Gunung Dewa Dewi dimulai pukul 05.00 WIB hingga pukul 21.00 WIB.  Saat ini, harga tiket masuk masih gratis, namun pengunjung dikenakan biaya parkir  sebesar Rp 3.000 untuk sepeda motor dan Rp 5.000 untuk mobil. Gunung Dewa Dewi  merupakan hasil kerja sama antara pemilik lahan dengan petani setempat dan dibantu  pengelolaannya oleh karang taruna Dusun Sumur. Di sana, terdapat tempat penjualan  yang diperuntukkan bagi warga Dusun Sumur untuk membantu meningkatkan  perekonomian warga sekitar.</div></td>
        <td>&nbsp;</td>
        <td valign="top"><div align="justify">Pertanian merupakan kegiatan utama yang banyak dijalankan oleh penduduk  Dusun Sumur sebagai sumber mata pencaharian utama mereka. Mereka menggarap  tanah yang dimiliki sendiri atau bekerja pada lahan sawah yang dimiliki oleh orang lain.  Jenis tanaman yang umumnya ditanam meliputi kedelai, padi, cabai, jagung, dan  berbagai jenis tanaman pangan lainnya. Hasil panen yang berupa bahan pokok biasanya  disimpan untuk kebutuhan pribadi, sementara hasil yang bukan merupakan bahan  pokok akan dijual. </div></td>
        <td>&nbsp;</td>
        <td valign="top"><div align="justify">Peternakan bukan hanya sekadar pekerjaan utama, melainkan sering kali  dianggap sebagai sumber penghasilan tambahan. Hampir seluruh penduduk memiliki  koleksi hewan ternak, seperti sapi, kambing, dan ayam, yang dianggap sebagai aset  milik mereka. Lebih dari sekadar tabungan, beberapa warga melihat potensi peternakan  sebagai peluang usaha yang dapat meningkatkan pendapatan mereka.</div></td>
      </tr>
    </table>
    <p align="center">&nbsp;</p>
</body>
</html>
